import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usertask',
  templateUrl: './usertask.component.html',
  styleUrls: ['./usertask.component.css']
})
export class UsertaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
