import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { TeamtaskComponent } from './teamtask/teamtask.component';
import { TeamtaskcardsComponent } from './teamtaskcards/teamtaskcards.component';
import { UsertaskComponent } from './usertask/usertask.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MytaskComponent } from './mytask/mytask.component';


@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    TeamtaskComponent,
    TeamtaskcardsComponent,
    UsertaskComponent,
    HomeComponent,
    LoginComponent,
    MytaskComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
