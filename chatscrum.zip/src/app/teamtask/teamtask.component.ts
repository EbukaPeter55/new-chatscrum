import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamtask',
  templateUrl: './teamtask.component.html',
  styleUrls: ['./teamtask.component.css']
})
export class TeamtaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
