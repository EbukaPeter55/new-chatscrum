import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytask',
  templateUrl: './mytask.component.html',
  styleUrls: ['./mytask.component.css']
})
export class MytaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
